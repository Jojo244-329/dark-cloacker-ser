<?php
    header("Location: /");
?>