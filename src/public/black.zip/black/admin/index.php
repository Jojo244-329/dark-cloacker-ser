<?php
    // altere aqui o login do painel admin
    define("USERNAME", "admin"); // nome de usuario
    define("PASSWORD", "12345"); // senha

    require_once("sessionManager.php");

    Session::startSession();

    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        if ($_POST["username"] == USERNAME && $_POST["password"] == PASSWORD) {
            Session::login();
            header("Location: dashboard.php");
            exit();
        }
    }
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <style>
        body {
            background-color: #f8f9fa;
        }

        .login {
            margin-top: 100px;
            padding: 20px;
        }

        .login h1 {
            color: #333;
            font-size: 28px;
            margin-bottom: 20px;
        }
        
        .form-floating label {
            color: #666;
        }

        .btn-primary {
            background-color: #007bff;
            border-color: #007bff;
        }

        .btn-primary:hover {
            background-color: #0056b3;
            border-color: #0056b3;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-4">
                <div class="login p-4">
                    <h1 class="text-center">Acesse sua conta</h1>
                    <form action="index.php" method="post">
                        <div class="mb-3">
                            <label for="username" class="form-label">Nome de usuário</label>
                            <input type="text" class="form-control" id="username" name="username" autocomplete="off">
                        </div>
                        <div class="mb-3">
                            <label for="password" class="form-label">Senha</label>
                            <input type="password" class="form-control" id="password" name="password">
                        </div>
                        <div class="d-grid">
                            <button class="btn btn-primary" type="submit">Login</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</body>
</html>
